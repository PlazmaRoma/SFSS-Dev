# SFSS Playground

## Run it

Double-click **SFSS Playground.html**. That is the whole program:
one file, no install, no server, works offline.

It starts on captured data: every figure comes from responses recorded from a
live run of the backend, so the numbers are real even with nothing running.
The three sliders work offline too. The model was sampled at 5950 points
across oxygen, pressure and droplet size, and the program interpolates
between them, so moving any slider moves the prediction.

## Live predictions and AI answers

Start the backend and the program picks it up within a few seconds, or
right away when you click back into the window. It looks for it at
`http://localhost:8000`.

    git clone https://github.com/PlazmaRoma/Anti-Fire_backend_MVP backend
    cd backend && python3 -m venv .venv && .venv/bin/pip install -r requirements.txt
    .venv/bin/uvicorn app.main:app

Needs Python 3.10 or newer. The AI answers also need LM Studio with a local
model. Two data files have to be fetched from NASA PSI by hand; the project
README explains which.

## Build it yourself

    cd source/frontend
    npm install
    npm run dev

## Where the numbers come from

- NASA NTRS: 16 reports, 998 pages
- NASA PSI, study PSI-25 (BASS-II): 129 runs
- NASA FLEX droplet matrix: 259 runs

Nothing is invented. Every figure is reproducible from the scripts in
`source/tools`.

Not affiliated with or endorsed by NASA.
