import { useMemo } from "react";
import type { Lang } from "../shared/types";
import type { Module } from "../shared/data/habitat";
import { band } from "../shared/lib/risk";
import { ModuleIcon } from "./ModuleIcon";
import { prettyUnits, tr } from "../shared/i18n";

/** Модули, отсортированные по риску, с номерами.
 *
 *  Задание требует не только обобщать и объяснять, но и ранжировать.
 *  Поэтому это не просто список для выбора: порядок здесь и есть ответ
 *  на вопрос «где опаснее всего», а номер читается с первого взгляда.
 */
export function ModuleRank({
  modules, ratios, values, units, selected, onSelect, lang,
}: {
  modules: Module[];
  ratios: Record<string, number>;
  values: Record<string, number>;
  units: string;
  selected: string;
  onSelect: (id: string) => void;
  lang: Lang;
}) {
  const ranked = useMemo(
    () => [...modules].sort((a, b) => (ratios[b.id] ?? 1) - (ratios[a.id] ?? 1)),
    [modules, ratios],
  );

  return (
    <div className="rank">
      <div className="rank-head">
        <h3>{tr("rankH", lang)}</h3>
      </div>

      <div className="rank-strip" role="tablist">
        {ranked.map((m, i) => {
          const ratio = ratios[m.id] ?? 1;
          return (
            <button
              key={m.id}
              role="tab"
              aria-selected={selected === m.id}
              className={selected === m.id ? "rank-item on" : "rank-item"}
              onClick={() => onSelect(m.id)}
            >
              <span className="rank-no">{i + 1}</span>
              {/* Иконка постоянно тёмно-синяя: она отвечает за «что это»,
                  а риск несёт только цифра справа. Один цвет — один смысл. */}
              <span className="rank-icon">
                <ModuleIcon id={m.id} size={20} />
              </span>
              <span className="rank-name">
                {m.name[lang]}
                <em>{values[m.id] !== undefined ? `${values[m.id].toFixed(3)} ${prettyUnits(units)}` : "·"}</em>
              </span>
              <span className={`rank-ratio ${band(ratio)}`}>{ratio.toFixed(2)}×</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
