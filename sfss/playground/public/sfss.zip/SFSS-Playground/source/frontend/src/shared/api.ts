import type { Answer, Atmosphere, CacheEntry, Dashboard, Health, PredictResponse, Source } from "../shared/types";
import { PSI_TO_MMHG } from "../shared/lib/risk";

import dashboardFixture from "../shared/fixtures/dashboard.json";
import healthFixture from "../shared/fixtures/health.json";
import queryCache from "../shared/fixtures/query_cache.json";
import cubeFixture from "../shared/fixtures/predict_cube.json";

const BASE = import.meta.env.VITE_API ?? "http://localhost:8000";

/** Бэкенд может быть не поднят — тогда всё берётся из снятых фикстур.
 *  Это не заглушка: файлы сняты с этого же бэкенда, цифры настоящие. */
export const cache = queryCache as unknown as Record<string, CacheEntry>;

async function get<T>(path: string, ms = 8000): Promise<T> {
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), ms);
  try {
    const res = await fetch(BASE + path, { signal: ctl.signal });
    if (!res.ok) throw new Error(`${path} → ${res.status}`);
    return (await res.json()) as T;
  } finally {
    clearTimeout(timer);
  }
}

async function post<T>(path: string, body: unknown, ms = 90_000): Promise<T> {
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), ms);
  try {
    const res = await fetch(BASE + path, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
      signal: ctl.signal,
    });
    if (!res.ok) throw new Error(`${path} → ${res.status}`);
    return (await res.json()) as T;
  } finally {
    clearTimeout(timer);
  }
}

export const fetchHealth = () => get<Health>("/health", 4000);
export const fetchDashboard = () => get<Dashboard>("/dashboard", 15_000);

export const offlineHealth = healthFixture as Health;
export const offlineDashboard = dashboardFixture as unknown as Dashboard;

export const toParams = (a: Atmosphere) => ({
  oxygen_level: Number(a.oxygen_level.toFixed(3)),
  n2: Number((1 - a.oxygen_level).toFixed(3)),
  pressure_mmhg: Number((a.pressure_psi * PSI_TO_MMHG).toFixed(1)),
  d_initial_mm: a.droplet_mm,
});

/** Пять секунд, а не пятнадцать: живой ответ приходит за десяток
 *  миллисекунд, и если бэкенд пропал, честнее быстро упасть на снятый
 *  куб, чем держать на экране старое число как будто оно новое. */
export const predict = (a: Atmosphere) =>
  post<PredictResponse>("/predict", { parameters: toParams(a) }, 5000);

/** Язык ответа — отдельное поле, а не просьба в тексте вопроса.
 *
 *  Раньше к вопросу приписывали «Answer in English.» или длинное «Ответь
 *  по-русски... переводи термины так: ...». Но вопрос целиком уходит в поиск,
 *  и русская приписка уводила его: на восьми готовых темах из 24 найденных
 *  фрагментов с поиском по голому вопросу совпадал один, и модель отвечала
 *  не по тем страницам. Поле `language` бэкенд кладёт только в промпт LLM,
 *  туда же — словарь терминов для русского.
 *
 *  Нужен бэкенд с этим полем (PlazmaRoma/Anti-Fire_backend_MVP#4). Старый
 *  его молча игнорирует, и на английский вопрос ответ придёт по-русски:
 *  системный промпт бэкенда русский.
 *
 *  Русский вопрос бэкенд сам ищет по английскому переводу (#5), в
 *  ответе перевод лежит в `search_query`. Фронту он не нужен. */
export const askLive = (question: string, lang: "en" | "ru") =>
  post<Answer>("/query", { question, language: lang });

/** Событие потока /query/stream, по одному на строку (NDJSON). */
export type StreamEvent =
  | { type: "sources"; sources: Source[]; search_query: string | null }
  | { type: "stage"; stage: "answering" | "translating" }
  | { type: "delta"; text: string }
  | { type: "done"; answer: string }
  | { type: "error"; detail: string };

/** Режет поток байт на строки JSON. Кусок может оборваться посреди строки
 *  и даже посреди буквы, поэтому хвост копится до следующего куска. */
export async function readEvents(body: ReadableStream<Uint8Array>, onEvent: (e: StreamEvent) => void) {
  const reader = body.getReader();
  const decoder = new TextDecoder();
  let tail = "";
  for (;;) {
    const { value, done } = await reader.read();
    tail += decoder.decode(value, { stream: !done });
    const lines = tail.split("\n");
    tail = lines.pop() ?? "";
    for (const line of lines) if (line.trim()) onEvent(JSON.parse(line) as StreamEvent);
    if (done) break;
  }
  if (tail.trim()) onEvent(JSON.parse(tail) as StreamEvent);
}

export interface Progress { sources: Source[] | null; stage: "searching" | "answering" | "translating"; text: string }

/** Тот же вопрос, но ответ показывается по мере генерации.
 *
 *  Полминуты пустого экрана — главное, что портило живой вопрос. Тайм-аут
 *  здесь не на весь ответ, а на тишину: длинный русский ответ идёт дольше
 *  90 секунд, но пока куски приходят, ждать есть чего.
 *
 *  Бэкенд без /query/stream отвечает 404 — тогда обычный /query. */
export async function askStream(
  question: string,
  lang: "en" | "ru",
  onProgress: (p: Progress) => void,
  silenceMs = 90_000,
): Promise<Answer> {
  const ctl = new AbortController();
  let timer = setTimeout(() => ctl.abort(), silenceMs);
  const alive = () => {
    clearTimeout(timer);
    timer = setTimeout(() => ctl.abort(), silenceMs);
  };
  try {
    const res = await fetch(BASE + "/query/stream", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ question, language: lang }),
      signal: ctl.signal,
    });
    if (res.status === 404) return askLive(question, lang);
    if (!res.ok || !res.body) throw new Error(`/query/stream → ${res.status}`);

    const p: Progress = { sources: null, stage: "searching", text: "" };
    let answer: string | null = null;
    await readEvents(res.body, (e) => {
      alive();
      if (e.type === "sources") p.sources = e.sources;
      else if (e.type === "stage") p.stage = e.stage;
      else if (e.type === "delta") p.text += e.text;
      else if (e.type === "done") answer = e.answer;
      else if (e.type === "error") throw new Error(e.detail);
      onProgress({ ...p });
    });
    if (answer === null) throw new Error("/query/stream оборвался без done");
    return { answer, sources: p.sources ?? [] };
  } finally {
    clearTimeout(timer);
    // После ошибки посреди потока соединение иначе висело бы открытым
    ctl.abort();
  }
}

/** Оффлайн-предсказание: снятый куб модели по трём осям и линейная
 *  интерполяция между узлами.
 *
 *  Куб снят с этого же бэкенда (tools/build_predict_cube.py): 25 шагов по
 *  кислороду, 14 по давлению, 17 по размеру капли. В сетку специально
 *  включены 14.7 и 8.2 psi: на них стоят все модули базы, и отношение
 *  1.40x должно совпадать с живой моделью до третьего знака. Ползунки
 *  идут мельче узлов, поэтому между ними считаем трилинейно: медиана
 *  расхождения 0.03 %, худший случай около 6 % у мелких капель.
 *
 *  Раньше здесь подбиралась ближайшая точка только по кислороду, и два
 *  ползунка из трёх цифру не двигали. По живой модели размер капли меняет
 *  скорость горения в 1.43 раза, так что это была не мелочь. */
type Cube = {
  oxygen_level: number[];
  pressure_psi: number[];
  droplet_mm: number[];
  values: number[][][];
  target: string;
  defaults_applied: string[];
  heuristic: number[] | null;
};
const cube = cubeFixture as unknown as Cube;

/** Номер нижнего узла и доля до следующего. За краями сетки прижимаем. */
function locate(axis: number[], v: number): [number, number] {
  if (v <= axis[0]) return [0, 0];
  const last = axis.length - 1;
  if (v >= axis[last]) return [last - 1, 1];
  let i = 0;
  while (i < last - 1 && axis[i + 1] <= v) i += 1;
  return [i, (v - axis[i]) / (axis[i + 1] - axis[i])];
}

export function predictOffline(a: Atmosphere): PredictResponse {
  const [io, fo] = locate(cube.oxygen_level, a.oxygen_level);
  const [ip, fp] = locate(cube.pressure_psi, a.pressure_psi);
  const [id, fd] = locate(cube.droplet_mm, a.droplet_mm);

  const at = (x: number, y: number, z: number) => cube.values[x][y][z];
  const mix = (lo: number, hi: number, f: number) => lo + (hi - lo) * f;

  const d00 = mix(at(io, ip, id), at(io, ip, id + 1), fd);
  const d01 = mix(at(io, ip + 1, id), at(io, ip + 1, id + 1), fd);
  const d10 = mix(at(io + 1, ip, id), at(io + 1, ip, id + 1), fd);
  const d11 = mix(at(io + 1, ip + 1, id), at(io + 1, ip + 1, id + 1), fd);
  const value = mix(mix(d00, d01, fp), mix(d10, d11, fp), fo);

  const nz = cube.pressure_psi.length * cube.droplet_mm.length;
  const flat = (io + (fo > 0.5 ? 1 : 0)) * nz
    + (ip + (fp > 0.5 ? 1 : 0)) * cube.droplet_mm.length
    + (id + (fd > 0.5 ? 1 : 0));

  return {
    predicted_value: value,
    risk_score: value,
    target: cube.target,
    defaults_applied: cube.defaults_applied,
    is_heuristic: cube.heuristic ? cube.heuristic[flat] === 1 : false,
  };
}
