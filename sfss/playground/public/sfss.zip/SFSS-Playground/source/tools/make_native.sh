#!/usr/bin/env bash
# Нативное приложение: то же самое, что в одном HTML-файле, но в своём окне.
#
# Внутри окна лежит ровно та страница, которую собирает make_source_zip.sh,
# поэтому расхождения между «программой» и «приложением» быть не может: оба
# берут один и тот же сваренный index.html.
#
# Запуск: bash tools/make_native.sh [--universal]
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
FE="$ROOT/frontend"
NAT="$ROOT/native"
export PATH="$HOME/.cargo/bin:$PATH"

command -v cargo >/dev/null || { echo "нет Rust: curl https://sh.rustup.rs -sSf | sh"; exit 1; }

echo "→ собираю программу и вплавляю её в окно"
mkdir -p "$NAT/dist"
( cd "$FE" && npx vite build --config vite.config.program.ts >/dev/null \
  && node tools/inline.mjs dist-program "$NAT/dist/index.html" )

[ -d "$NAT/node_modules" ] || ( cd "$NAT" && npm install >/dev/null )

if [ "${1:-}" = "--universal" ]; then
  # Универсальная сборка идёт под Intel и Apple Silicon сразу: у судьи может
  # быть любой Mac, а неподходящая сборка просто не запустится.
  rustup target add x86_64-apple-darwin aarch64-apple-darwin >/dev/null 2>&1 || true
fi

echo "→ собираю приложение"
if [ "${1:-}" = "--universal" ]; then
  ( cd "$NAT" && npx tauri build --target universal-apple-darwin )
else
  ( cd "$NAT" && npx tauri build )
fi

BUNDLE="$NAT/src-tauri/target/${1:+universal-apple-darwin/}release/bundle"
[ "${1:-}" = "--universal" ] || BUNDLE="$NAT/src-tauri/target/release/bundle"
find "$BUNDLE" -maxdepth 2 -name '*.app' -o -maxdepth 2 -name '*.dmg' | while read -r f; do
  echo "→ $f  ($(du -sh "$f" | cut -f1))"
done
