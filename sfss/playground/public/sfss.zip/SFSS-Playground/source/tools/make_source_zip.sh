#!/usr/bin/env bash
# Собирает то, что скачивают кнопкой на лендинге:
#   1. саму программу одним HTML-файлом, запускается двойным кликом
#   2. исходники, если кто-то захочет собрать сам
# Запуск: bash tools/make_source_zip.sh
set -eu
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
FE="$ROOT/frontend"
OUT="$FE/public/sfss.zip"
STAGE="$(mktemp -d)/SFSS-Playground"
mkdir -p "$STAGE"

# --- программа одним файлом -------------------------------------------------
( cd "$FE" && npx vite build --config vite.config.program.ts >/dev/null   && node tools/inline.mjs dist-program "$STAGE/SFSS Playground.html" )

# --- исходники --------------------------------------------------------------
mkdir -p "$STAGE/source/frontend"
for p in src public index.html app.html package.json package-lock.json tsconfig.json \
         tsconfig.app.json tsconfig.node.json vite.config.ts vite.config.program.ts \
         tools .oxlintrc.json .gitignore; do
  [ -e "$FE/$p" ] && cp -R "$FE/$p" "$STAGE/source/frontend/" || true
done
# Видео и сам архив внутрь не кладём: 13 МБ и рекурсия
# Видео и сам архив внутрь архива не кладём. Путь до медиа задан поиском, а
# не жёсткой строкой: после переезда в src/shared/media жёсткая строка молча
# перестала совпадать, и архив раздулся с 414 КБ до 13.6 МБ.
find "$STAGE/source" -name '*.mp4' -delete
rm -f "$STAGE/source/frontend/public/sfss.zip"
cp -R "$ROOT/fixtures" "$STAGE/source/fixtures"
mkdir -p "$STAGE/source/tools"
cp "$ROOT/tools/"*.py "$ROOT/tools/"*.sh "$STAGE/source/tools/" 2>/dev/null || true
cp "$ROOT/README.md" "$STAGE/source/" 2>/dev/null || true

cat > "$STAGE/START-HERE.md" <<'EOF'
# SFSS Playground

## Run it

Double-click **SFSS Playground.html**. That is the whole program:
one file, no install, no server, works offline.

It starts on captured data: every figure comes from responses recorded from a
live run of the backend, so the numbers are real even with nothing running.
The three sliders work offline too. The model was sampled at 5950 points
across oxygen, pressure and droplet size, and the program interpolates
between them, so moving any slider moves the prediction.

## Live predictions and AI answers

Start the backend and the program picks it up within a few seconds, or
right away when you click back into the window. It looks for it at
`http://localhost:8000`.

    git clone https://github.com/PlazmaRoma/Anti-Fire_backend_MVP backend
    cd backend && python3 -m venv .venv && .venv/bin/pip install -r requirements.txt
    .venv/bin/uvicorn app.main:app

Needs Python 3.10 or newer. The AI answers also need LM Studio with a local
model. Two data files have to be fetched from NASA PSI by hand; the project
README explains which.

## Build it yourself

    cd source/frontend
    npm install
    npm run dev

## Where the numbers come from

- NASA NTRS: 16 reports, 998 pages
- NASA PSI, study PSI-25 (BASS-II): 129 runs
- NASA FLEX droplet matrix: 259 runs

Nothing is invented. Every figure is reproducible from the scripts in
`source/tools`.

Not affiliated with or endorsed by NASA.
EOF

rm -f "$OUT" "$FE/public/sfss-source.zip"
( cd "$(dirname "$STAGE")" && zip -rq "$OUT" "SFSS-Playground" -x '*.DS_Store' )
rm -rf "$(dirname "$STAGE")"
# Размер архива подписан на кнопке скачивания. Руками он рассыхается,
# поэтому правим его тем же скриптом, который архив и собирает.
KB=$(( ($(wc -c < "$OUT") + 512) / 1024 ))
I18N="$FE/src/shared/i18n.ts"
python3 - "$I18N" "$KB" <<'PYEOF'
import re, sys
path, kb = sys.argv[1], sys.argv[2]
s = open(path).read()
new = re.sub(r'(grabMeta: \{ en: "ZIP · )\d+( KB)', rf'\g<1>{kb}\g<2>', s)
new = re.sub(r'(ru: "ZIP · )\d+( КБ)', rf'\g<1>{kb}\g<2>', new)
if new != s:
    open(path, "w").write(new)
    print(f"  подпись на кнопке: {kb} КБ")
PYEOF

echo "→ $OUT  ($(du -h "$OUT" | cut -f1))"
